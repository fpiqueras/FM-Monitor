#ifndef RCALC_H
#define RCALC_H

#include "pane.h"

class RankCalculator : public Pane {
};

#endif //RCALC_H