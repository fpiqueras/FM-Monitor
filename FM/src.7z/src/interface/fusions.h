#ifndef FUSIONS_H
#define FUSIONS_H

#include "pane.h"

class Fusions : public Pane {
};

#endif //FUSIONS_H