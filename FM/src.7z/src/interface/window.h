#ifndef WINDOW_H
#define WINDOW_H

#include "pane.h"

class Window : public Pane {
};

#endif //WINDOW_H