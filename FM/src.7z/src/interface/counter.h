#ifndef COUNTER_H
#define COUNTER_H

#include "pane.h"

class Counter : public Pane {
};

#endif //COUNTER_H