#ifndef DUELISTS_H
#define DUELISTS_H

#include "pane.h"

class Duelists : public Pane {
};

#endif //DUELISTS_H