#ifndef CODES_H
#define CODES_H

#include "pane.h"

class Codes : public Pane {
};

#endif //CODES_H