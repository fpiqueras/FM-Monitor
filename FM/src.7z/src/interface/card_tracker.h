#ifndef CTRACKER_H
#define CTRACKER_H

#include "pane.h"

class CardTracker : public Pane {
};

#endif //CTRACKER_H