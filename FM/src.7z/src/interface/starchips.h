#ifndef STARCHIPS_H
#define STARCHIPS_H

#include "pane.h"

class Starchips : public Pane {
};

#endif //STARCHIPS_H