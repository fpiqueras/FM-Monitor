#ifndef PANE_H
#define PANE_H

class Pane {
};

#endif //MPANE_H