#ifndef HISTORY_H
#define HISTORY_H

#include "pane.h"

class History : public Pane {
};

#endif //HISTORY_H