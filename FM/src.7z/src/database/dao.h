#ifndef DAO_H
#define DAO_H

class Dao {
};

#endif //DAO_H